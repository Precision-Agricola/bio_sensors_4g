# client/config/config.py

RTC_CLK_PIN = 16 # TODO: RTC pin obsolete
RTC_DIO_PIN = 21 # TODO: RTC pin obsolete
RTC_CS_PIN = 23 # TODO: RTC pin obsolete
I2C_BUS_ID = 1
I2C_SCL_PIN = 23
I2C_SDA_PIN = 21
SWITCH_PIN = 15
RECIRCULATION_POMP_PIN = 12
STATUS_LIGHT_PIN = 14
