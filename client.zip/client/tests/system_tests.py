def run_initial_tests():
    print("Running Initial Tests")
    print("Running RTC - to implement")
    print("Running aerator - to implement")
    print("Running sensors - to implement")

if __name__ == "__main__":
    run_initial_tests()